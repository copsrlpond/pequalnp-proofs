import Mathlib

namespace SymmetricStar

-- Expansion from the project's checked module PEqualNP.Outside.L_gct_222.
lemma sum_perm_succ {n : ℕ} (f : Equiv.Perm (Fin (n + 1)) → ℂ) :
    ∑ σ, f σ = ∑ p : Fin (n + 1), ∑ τ : Equiv.Perm (Fin n), f (Equiv.Perm.decomposeFin.symm (p, τ)) := by
  rw [← Equiv.Perm.decomposeFin.symm.sum_comp, Fintype.sum_prod_type]

lemma perm4 (M : Matrix (Fin 4) (Fin 4) ℂ) : Matrix.permanent M =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 + M 0 0 * M 1 1 * M 3 2 * M 2 3 + M 0 0 * M 2 1 * M 1 2 * M 3 3
  + M 0 0 * M 2 1 * M 3 2 * M 1 3 + M 0 0 * M 3 1 * M 1 2 * M 2 3 + M 0 0 * M 3 1 * M 2 2 * M 1 3
  + M 1 0 * M 0 1 * M 2 2 * M 3 3 + M 1 0 * M 0 1 * M 3 2 * M 2 3 + M 1 0 * M 2 1 * M 0 2 * M 3 3
  + M 1 0 * M 2 1 * M 3 2 * M 0 3 + M 1 0 * M 3 1 * M 0 2 * M 2 3 + M 1 0 * M 3 1 * M 2 2 * M 0 3
  + M 2 0 * M 0 1 * M 1 2 * M 3 3 + M 2 0 * M 0 1 * M 3 2 * M 1 3 + M 2 0 * M 1 1 * M 0 2 * M 3 3
  + M 2 0 * M 1 1 * M 3 2 * M 0 3 + M 2 0 * M 3 1 * M 0 2 * M 1 3 + M 2 0 * M 3 1 * M 1 2 * M 0 3
  + M 3 0 * M 0 1 * M 1 2 * M 2 3 + M 3 0 * M 0 1 * M 2 2 * M 1 3 + M 3 0 * M 1 1 * M 0 2 * M 2 3
  + M 3 0 * M 1 1 * M 2 2 * M 0 3 + M 3 0 * M 2 1 * M 0 2 * M 1 3 + M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  simp only [Matrix.permanent]
  rw [sum_perm_succ]
  simp only [sum_perm_succ (n := 2), sum_perm_succ (n := 1), sum_perm_succ (n := 0)]
  simp only [Fin.sum_univ_succ, Fin.sum_univ_zero, Fin.prod_univ_succ, Fin.prod_univ_zero,
    Equiv.Perm.decomposeFin_symm_apply_zero, Equiv.Perm.decomposeFin_symm_apply_succ,
    Fintype.sum_unique]
  simp +decide [Equiv.swap_apply_def]
  ring


def symmetric (d x y z p q r l m n : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  !![d,x,y,z; x,p,l,m; y,l,q,n; z,m,n,r]

def bottom (p q r l m n : ℂ) : ℂ :=
  p*q*r + p*n^2 + q*m^2 + r*l^2 + 2*l*m*n

def quad (p q r l m n x y z : ℂ) : ℂ :=
  (q*r+n^2)*x^2 + (p*r+m^2)*y^2 + (p*q+l^2)*z^2
    + 2*(l*r+m*n)*x*y + 2*(l*n+q*m)*x*z + 2*(p*n+l*m)*y*z

lemma symmetric_permanent (d x y z p q r l m n : ℂ) :
    (symmetric d x y z p q r l m n).permanent =
    d * bottom p q r l m n + quad p q r l m n x y z := by
  rw [perm4]
  simp [symmetric, quad, bottom]
  ring

-- Constancy on the zero-sum star kills the quadratic in each of its directions.
lemma star_quad {d x y z p q r l m n : ℂ}
    (h : ∀ u v : ℂ, d * bottom p q r l m n +
      quad p q r l m n (x+u) (y+v) (z-u-v) = 24)
    (u v : ℂ) : quad p q r l m n u v (-u-v) = 0 := by
  have hp := h u v
  have hm := h (-u) (-v)
  have hz := h 0 0
  unfold quad at hp hm hz ⊢
  linear_combination (hp + hm - 2 * hz) / 2

lemma cofactor_pair (A B C : ℂ)
    (h : ∀ s : ℂ, (1+s*C)*s*A + s^2*B^2 = 0) : A = 0 ∧ B = 0 := by
  have hp := h 1
  have hm := h (-1)
  have ha : A = 0 := by linear_combination (hp - hm) / 2
  have hb : B^2 = 0 := by linear_combination hp - (1+C)*ha
  exact ⟨ha, pow_eq_zero_iff (by decide : 2 ≠ 0) |>.mp hb⟩

-- Every symmetric Y whose span with the star stays at permanent 24 is in that star.
theorem maximal_star (d x y z p q r l m n : ℂ)
    (h : ∀ s u v : ℂ,
      (symmetric (1+s*d) (1+s*x+u) (1+s*y+v) (1+s*z-u-v)
        (1+s*p) (1+s*q) (1+s*r) (1+s*l) (1+s*m) (1+s*n)).permanent = 24) :
    d = 0 ∧ x+y+z = 0 ∧ p = 0 ∧ q = 0 ∧ r = 0 ∧ l = 0 ∧ m = 0 ∧ n = 0 := by
  simp only [symmetric_permanent] at h
  have hQ (s u v : ℂ) := star_quad (h s) u v
  have h12 := cofactor_pair (p+q-2*l) (m-n) r (by
    intro s
    have hh := hQ s 1 (-1)
    unfold quad at hh
    linear_combination hh)
  have h13 := cofactor_pair (p+r-2*m) (l-n) q (by
    intro s
    have hh := hQ s 1 0
    unfold quad at hh
    linear_combination hh)
  have h23 := cofactor_pair (q+r-2*n) (l-m) p (by
    intro s
    have hh := hQ s 0 1
    unfold quad at hh
    linear_combination hh)
  obtain ⟨hpq, hmn⟩ := h12
  obtain ⟨hpr, hln⟩ := h13
  obtain ⟨hqr, _⟩ := h23
  have hl : l = n := by linear_combination hln
  have hm : m = n := by linear_combination hmn
  subst l
  subst m
  have hp : p = n := by linear_combination (hpq + hpr - hqr) / 2
  have hq : q = n := by linear_combination (hpq + hqr - hpr) / 2
  have hr : r = n := by linear_combination (hpr + hqr - hpq) / 2
  subst p
  subst q
  subst r
  have hn : n = 0 := by
    by_contra hne
    have hz := h (-n⁻¹) 0 0
    have hc : (1 : ℂ) + -n⁻¹ * n = 0 := by
      field_simp
      ring
    rw [hc] at hz
    norm_num [quad, bottom] at hz
  subst n
  have hp := h 1 0 0
  have hm := h (-1) 0 0
  simp only [quad, bottom] at hp hm
  have hs : (x+y+z)^2 = 0 := by linear_combination (hp + hm) / 4
  have hs' : x+y+z = 0 := (pow_eq_zero_iff (by decide : 2 ≠ 0)).mp hs
  have hd : d = 0 := by linear_combination (hp - hm - 24*hs') / 12
  exact ⟨hd, hs', rfl, rfl, rfl, rfl, rfl, rfl⟩

-- The star itself does attain the level.
theorem star_attains (u v : ℂ) :
    (symmetric 1 (1+u) (1+v) (1-u-v) 1 1 1 1 1 1).permanent = 24 := by
  rw [symmetric_permanent]
  unfold bottom quad
  ring

end SymmetricStar

