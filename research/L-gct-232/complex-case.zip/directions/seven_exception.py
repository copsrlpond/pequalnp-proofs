"""Quadric RREF chart systems for the rank-two exceptional direction at 7."""
import itertools as it
from pathlib import Path
import geometric as g
import exceptional as e

g.P = e.P = 7
def witt(forms,n):
    quad=forms[0][1]
    q=lambda u:e.evalform(quad,u)
    def bil(u,v):return (q(e.add(u,v))-q(u)-q(v))%7
    U=[[int(i==j) for i in range(n)] for j in range(n)]
    left=[];right=[]
    for _ in range(n//2):
        u=next(t for t in (e.compose(c,U) for c in it.product(range(7),repeat=len(U)) if any(c)) if not q(t))
        v=next(t for t in U if bil(u,t))
        v=[x*pow(bil(u,v),-1,7)%7 for x in v]
        v=e.add(v,u,-q(v))
        E=[[bil(a,z) for z in U] for a in (u,v)]
        U=[e.compose(s,U) for s in g.nullspace(E,len(U))]
        left.append(u);right.append(v)
    return left+U+right[::-1],q(U[0])

def lines(n,k,i,j):
    a=[];b=[];la=0
    for rows,p in ((a,i),(b,j)):
        for c in range(n):
            if c==p: rows.append({0:1})
            elif c<p or c==i or c==j: rows.append({})
            elif ((rows is a and c==n-1-i) or
                  (rows is b and c==n-1-j) or
                  (rows is b and c==n-1-i)):rows.append({})
            else:rows.append({1<<(8*la):1});la+=1
    def quad(x):
        val=e.scale(e.pmul(x[n//2],x[n//2]),k)
        for d in range(n//2):val=e.padd(val,e.pmul(x[d],x[n-1-d]))
        return val
    if i<n//2:a[n-1-i]=e.scale(quad(a),-1)
    if j<n//2:b[n-1-j]=e.scale(quad(b),-1)
    if i+j<n-1:b[n-1-i]=e.scale(quad([e.padd(v,w) for v,w in zip(a,b)]),-1)
    for t in range(3):assert not quad([e.padd(v,w,t) for v,w in zip(a,b)])
    return a,b,la

def to_text(poly,n):
    def mon(m):
        f=[]
        for j in range(n):
            exponent=m>>(8*j)&255
            if exponent:
                s='v'+str(j)
                f.append(s if exponent==1 else s+'^'+str(exponent))
        return f
    return '+'.join('*'.join([str(c)]+mon(m)) for m,c in poly.items()) or '0'

def gen(directory=Path('.')):
    A=[0,0,0,0,0,0,0,1,4,5]
    T=g.tangent(A)
    forms=g.polys(A,T)
    n=len(T)
    wb,k=witt(forms,n)
    bs=[e.compose(v,T) for v in wb]
    forms=g.polys(A,bs)
    for i,j in it.combinations(range(n),2):
        if n//2 in (i,j) or i+j==n-1:continue
        a,b,r=lines(n,k,i,j)
        equations=[]
        for deg, f in forms:
            for t in range(deg+1):
                x=[e.padd(u,v,t) for u,v in zip(a,b)]
                summ={}
                for m,c in f.items():
                    term={0:c}
                    for col in range(n):
                        for _ in range((m>>(4*col))%16):term=e.pmul(term,x[col])
                    summ=e.padd(summ,term)
                if summ and summ not in equations:equations.append(summ)
        fname=directory/('seven-chart-'+str(i)+str(j)+'.in')
        variables=','.join('v'+str(l) for l in range(max(1,r)))
        fname.write_text(variables+'\n7\n'+',\n'.join(to_text(f,r) for f in equations)+'\n',encoding='ascii')
        print(i,j,r,len(equations))
if __name__=='__main__':gen()
