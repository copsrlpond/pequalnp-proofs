"""Geometric incidence sieve at 7; uses the common matrix and polynomial code."""
import random
from collections import Counter
import geometric as g

g.P = 7
reps = g.reps()
rng = random.Random(787)
hist = Counter()
ordinary=0
exceptional={(0,0,0,0,0,0,0,1,4,5),(0,0,0,0,0,0,1,0,6,0)}
assert len(reps)==731 and all(dict(reps)[a]==12 for a in exceptional)
for index, (a, size) in enumerate(reps):
    if a in exceptional:
        continue
    space = g.tangent(a)
    passed = False
    for _ in range(10):
        basis = g.slice_basis(space, rng)
        forms = g.polys(a, basis)
        for d in (6,7,8):
            if g.hilbert(len(basis), forms, d) == 0:
                passed = True
                hist[d] += 1
                break
        if passed:
            break
    assert passed, ('ordinary direction failed',a)
    ordinary += size
assert ordinary==17064 and sum(hist.values())==729
print('ordinary directions',ordinary,'certificate degrees',dict(hist))
