"""Complete the geometric calculation at the exceptional rational direction.

The two opposite leaf entries of the star are +1 and -1. A quadratic polar
combination forces a linear equation on every possible extension. In this
hyperplane, subtracting a multiple of the star leaves identical rows and
columns at the two leaf positions. A geometric three-space containing the
star would therefore have a two-dimensional duplicate-row subspace.

The tangent quadratic for the duplicate-row problem has Witt coordinates
x0*x4 + x1*x3 + k*x2^2. An isotropic plane has no pivot at 2 and cannot
have complementary pivots 0,4 or 1,3. The four other RREF pivot charts
are the polynomial parameterizations in chart(). For each, the code proves
that 1 belongs to the cubic/quartic restriction ideal by exact F_5 row
reduction. This excludes a solution over every extension of F_5.
"""
from collections import defaultdict
import functools, itertools as it, math
import numpy as np
from geometric import P, idx, ij, mons, nullspace, polys, tangent

def add(u,v,k=1):return [(x+k*y)%P for x,y in zip(u,v)]
def dot(u,v):return sum(x*y for x,y in zip(u,v))%P
def compose(u,bs):return [sum(c*v[j] for c,v in zip(u,bs))%P for j in range(len(bs[0]))]
def evalform(eq,u):
    return sum(c*math.prod(u[j]**((m>>(4*j))%16) for j in range(len(u))) for m,c in eq.items())%P
def witt(bs):
    eq=polys([0]*10,bs)[0][1]
    n=len(bs)
    q=lambda u:evalform(eq,u)
    def bil(u,v):return (q(add(u,v))-q(u)-q(v))%P
    U=[[int(i==j) for i in range(n)] for j in range(n)]
    left=[];right=[]
    for _ in range(2):
        e=next(t for t in (compose(c,U) for c in it.product(range(P),repeat=len(U)) if any(c)) if not q(t))
        f=next(t for t in U if bil(e,t))
        f=[x*pow(bil(e,f),-1,P)%P for x in f]
        f=add(f,e,-q(f))
        E=[[bil(v,u) for u in U] for v in (e,f)]
        U=[compose(row,U) for row in nullspace(E,len(U))]
        left.append(e);right.append(f)
    basis=left+U+right[::-1]
    return [compose(t,bs) for t in basis],q(U[0])

def duplicate_basis():
    rows=[]
    for i in range(4):
        e=[0]*10;e[idx(0,i)]+=1;e[idx(1,i)]-=1;rows.append(e)
    rows.append([1 if i==j else 2 for i,j in ij])
    return nullspace(rows,10)

def verify_duplicate_reduction():
    # Center 3, opposite leaves 1 and 2. The first remaining leaf is 0.
    A=[0,0,0,0,0,0,1,0,P-1,0]
    T=tangent(A)
    assert len(T)==6
    ell=[(b[idx(0,1)]-b[idx(0,2)])%P for b in T]
    # Prove ell(B)^2=0 on all possible extensions, including over the
    # algebraic closure, by expressing the square as a linear combination
    # of the exact quadratic polar equations on the tangent quotient.
    quadratic=[f for d,f in polys(A,T) if d==2]
    lin={1<<(4*i):c for i,c in enumerate(ell) if c}
    square=pmul(lin,lin)
    rows=[[f.get(m,0) for f in quadratic]+[-square.get(m,0)] for m in mons(6,2)]
    relation=next(v for v in nullspace(rows,len(quadratic)+1) if v[-1])
    relation=[x*pow(relation[-1],-1,P)%P for x in relation]
    rhs={}
    for c,f in zip(relation,quadratic):rhs=padd(rhs,f,c)
    assert square==rhs
    Bspace=[compose(row,T) for row in nullspace([ell],len(T))]
    assert len(Bspace)==5
    for B in Bspace:
        c=(B[idx(1,3)]-B[idx(2,3)])*pow(2,-1,P)%P
        Y=add(B,A,-c)
        assert all(Y[idx(1,j)]==Y[idx(2,j)] for j in range(4))
    print('exceptional direction: square of residual linear constraint equals polar combination',
          relation[:-1],'; residual quotient is duplicate-row',flush=True)

def padd(a,b,c=1):
    z=a.copy()
    for m,n in b.items():
        val=(z.get(m,0)+c*n)%P
        if val:z[m]=val
        elif m in z:del z[m]
    return z
def pmul(a,b):
    z=defaultdict(int)
    for i,c in a.items():
        for j,d in b.items():z[i+j]+=c*d
    return {m:c%P for m,c in z.items() if c%P}
def scale(a,c):return {m:(v*c)%P for m,v in a.items() if v*c%P}

def chart(k,i):
    # Base 256 exponent packing for chart coordinates.
    A,B,D=[{1<<(8*j):1} for j in range(3)]; one={0:1};zero={}
    if i==0:
        return [one,zero,A,B,scale(pmul(A,A),-k)],[zero,one,D,scale(pmul(D,D),-k),padd(scale(B,-1),pmul(A,D),-2*k)],3
    if i==1:
        return [one,A,B,zero,scale(pmul(B,B),-k)],[zero,zero,zero,one,scale(A,-1)],2
    if i==2:
        return [zero,one,A,scale(pmul(A,A),-k),zero],[zero,zero,zero,zero,one],1
    return [zero,zero,zero,one,zero],[zero,zero,zero,zero,one],0

def chart_eqs(bs,k,i):
    forms=dict(polys([0]*10,bs))
    r1,r2,n=chart(k,i)
    eqs=[]
    for d in [2,3,4]:
        for t in range(d+1):
            v=[padd(a,b,t) for a,b in zip(r1,r2)]
            eq={}
            for m,c in forms[d].items():
                term={0:c}
                for j,u in enumerate(v):
                    for _ in range((m>>(4*j))%16):term=pmul(term,u)
                eq=padd(eq,term)
            if d==2:assert not eq
            elif eq:eqs.append(eq)
    return n,eqs

@functools.lru_cache(None)
def smallmons(n,d):
    return [sum(1<<(8*j) for j in a) for dd in range(d+1) for a in it.combinations_with_replacement(range(n),dd)]
def degree(a,n):return sum(a>>(8*j)&255 for j in range(n))
def in_ideal_macaulay(n,eqs,d):
    target=smallmons(n,d)
    inds={m:k for k,m in enumerate(target)}
    rows=[(eq,off) for eq in eqs for off in smallmons(n,d-max(degree(a,n) for a in eq))]
    h=np.zeros((len(rows),len(target)),dtype=np.int16)
    for i,(eq,off) in enumerate(rows):
        for m,c in eq.items():h[i,inds[m+off]]=c
    # Reverse column order. Last column is the constant; pivot there iff 1 belongs to row space.
    rank=0
    for j in range(len(target)-1,-1,-1):
        pivs=np.flatnonzero(h[rank:,j])
        if not len(pivs):continue
        if j==0:return True
        row=rank+pivs[0]
        if row!=rank:h[[row,rank]]=h[[rank,row]]
        pivot=h[rank,:j+1]
        pivot[:]=(pivot*pow(int(pivot[-1]),-1,P))%P
        sel=rank+1+np.flatnonzero(h[rank+1:,j])
        if len(sel):h[sel,:j+1]=(h[sel,:j+1]-h[sel,j,None]*pivot)%P
        rank+=1
        if rank==len(rows):break
    return False

if __name__=='__main__':
    verify_duplicate_reduction()
    bs,k=witt(duplicate_basis())
    assert k==3
    print('Witt coefficient',k)
    for i in range(4):
        n,eqs=chart_eqs(bs,k,i)
        for d in range(4,16):
            ok=in_ideal_macaulay(n,eqs,d)
            if ok:break
        assert ok,('no unit certificate for chart',i)
        print('chart',i,'dimension',n,'unit certified at Macaulay degree',d,flush=True)
