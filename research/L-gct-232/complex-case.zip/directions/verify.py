"""Run the incidence certificates at one or both primes, without writing into the source directory."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent

def run_python(script):
    subprocess.run([sys.executable,str(ROOT/script)],check=True)

def verify_seven(solver):
    import geometric as g
    import exceptional as e
    import seven_exception as seven
    g.P=e.P=7
    e.verify_duplicate_reduction()
    bs,k=e.witt(e.duplicate_basis())
    for chart in range(4):
        n,forms=e.chart_eqs(bs,k,chart)
        degree=next((d for d in range(2,18) if e.in_ideal_macaulay(n,forms,d)),None)
        assert degree is not None,('no unit certificate',chart)
        print('star at 7, chart',chart,'unit certified at degree',degree)
    with tempfile.TemporaryDirectory() as tmp:
        directory=Path(tmp)
        seven.gen(directory)
        inputs=sorted(directory.glob('seven-chart-*.in'))
        assert len(inputs)==12
        for source in inputs:
            dest=source.with_suffix('.out')
            subprocess.run([solver,'-l','2','-t','1','-s','14','-g','2',
                            '-f',str(source),'-o',str(dest)],check=True)
            basis=''.join(line.strip() for line in dest.read_text().splitlines()
                          if not line.startswith('#'))
            assert basis=='[1]:',(source.name,basis[:100])
            print('second orbit at 7,',source.stem,'unit basis')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prime',choices=['5','7','both'],default='5')
    parser.add_argument('--msolve',default=os.getenv('MSOLVE','msolve'))
    args=parser.parse_args()
    if args.prime in ('5','both'):
        run_python('geometric.py')
        run_python('exceptional.py')
    if args.prime in ('7','both'):
        solver=shutil.which(args.msolve)
        if solver is None:
            parser.error('the mod-7 calculation requires msolve; pass --msolve /path/to/msolve')
        run_python('prime7.py')
        verify_seven(solver)

if __name__=='__main__':
    main()
