"""Exclude two-dimensional level spaces supported on a principal 3-by-3 block.

All four first-row coordinates vanish, and tangency at J kills the total
entry sum. The remaining quadratic space has dimension five. Its maximal
isotropic planes are covered by the four Witt charts in exceptional.py.
"""
from geometric import P, ij, nullspace, polys
from exceptional import chart, in_ideal_macaulay, padd, pmul, witt


def check():
    constraints = [[int(j == i) for j in range(10)] for i in range(4)]
    constraints.append([1 if i == j else 2 for i, j in ij])
    basis, center = witt(nullspace(constraints, 10))
    # At A=0 each of the evaluations used to construct a degree-k polar
    # is the same homogeneous form. The quartic is zero on this support.
    forms = dict(polys([0] * 10, basis))
    assert set(forms) == {2, 3}
    for i, expected_degree in enumerate((14, 8, 9, 3)):
        a, b, nvars = chart(center, i)
        equations = []
        for degree, form in forms.items():
            # d+1 evaluations determine a binary form of degree d; here d<5.
            for s in range(degree + 1):
                values = [padd(x, y, s) for x, y in zip(a, b)]
                restriction = {}
                for monomial, coefficient in form.items():
                    term = {0: coefficient}
                    for j, entry in enumerate(values):
                        for _ in range((monomial >> (4*j)) & 15):
                            term = pmul(term, entry)
                    restriction = padd(restriction, term)
                if degree == 2:
                    assert not restriction
                elif restriction:
                    equations.append(restriction)
        assert in_ideal_macaulay(nvars, equations, expected_degree)
        print(f"Principal support chart {i}: unit certified at degree {expected_degree} over F_{P}")


if __name__ == "__main__":
    check()
