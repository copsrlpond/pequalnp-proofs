"""Check ordinary rational directions over the algebraic closure of F_5.

Run with Python 3 and NumPy. Run exceptional.py for the remaining orbit.

For a direction A, a second direction B extends A only if all coefficients
in u and s of per(J + s*A + u*B) - 24 vanish. The linear coefficients give
the tangent quotient modulo A. If A lay on a three-dimensional level space,
the quotient would contain a projective line of solutions of the remaining
forms. Every projective line meets every hyperplane. We exhibit a hyperplane
for which the restricted forms span all monomials through their multiples
in a specified degree, ruling out even a geometric projective intersection.
The seeded random generator only proposes hyperplanes. A failed proposal
never counts as a certificate.
"""
import itertools as it
import functools, math, random
from collections import defaultdict,Counter
import numpy as np

P=5
ij=list(it.combinations_with_replacement(range(4),2))
ix={v:k for k,v in enumerate(ij)}
def idx(i,j): return ix[tuple(sorted((i,j)))]
perms=list(it.permutations(range(4)))
terms=Counter(tuple(sorted(idx(i,j) for i,j in enumerate(s))) for s in perms)
def norm(v): return tuple((int(x)*pow(next(int(a) for a in v if a),-1,P))%P for x in v)
def reps():
    # Vectorized enumeration of normalized points of the total-entry-sum-zero hyperplane.
    total=np.array([1 if i==j else 2 for i,j in ij[:9]])
    found=set()
    for k in range(9):
        for n in range(0,P**(8-k),10000):
            count=min(10000,P**(8-k)-n)
            x=np.zeros((count,10),dtype=np.int64)
            x[:,k]=1
            values=np.arange(n,n+count,dtype=np.int64)
            for j in range(k+1,9): x[:,j],values=values%P,values//P
            x[:,9]=(-x[:,:9]@total)%P
            for s in range(1,5):
                y=1+s*x
                value=sum(m*y[:,a]*y[:,b]*y[:,c]*y[:,d] for (a,b,c,d),m in terms.items())
                x=x[(value-24)%P==0]
            found.update(tuple(map(int,v)) for v in x)
    initial=len(found)
    os=[]
    while found:
        a=min(found)
        orb={norm([a[idx(s[i],s[j])] for i,j in ij]) for s in perms}
        assert orb <= found
        found-=orb
        os.append((a,len(orb)))
    print('directions',initial,'S4 orbits',len(os),flush=True)
    return os

def nullspace(rows,n):
    a=[[x%P for x in row] for row in rows]
    piv=[]
    for j in range(n):
        l=len(piv)
        r=next((r for r in range(l,len(a)) if a[r][j]),None)
        if r is None:continue
        a[r],a[l]=a[l],a[r]
        a[l]=[v*pow(a[l][j],-1,P)%P for v in a[l]]
        for i in range(len(a)):
            if i!=l:
                c=a[i][j]
                a[i]=[(v-c*w)%P for v,w in zip(a[i],a[l])]
        piv.append(j)
    ret=[]
    for j in range(n):
        if j in piv: continue
        v=[0]*n;v[j]=1
        for i,k in enumerate(piv): v[k]=(-a[i][j])%P
        ret.append(v)
    return ret

def tangent(A):
    """Kernel of four evaluated cubic gradients, modulo the direction A."""
    rows=[]
    for s in range(4):
        q=[1+s*a for a in A]
        grad=[0]*10
        for t,m in terms.items():
            for i,j in enumerate(t):grad[j]+=m*math.prod(q[k] for k in t[:i]+t[i+1:])
        rows.append(grad)
    rows.append([int(i==next(i for i,v in enumerate(A) if v)) for i in range(10)])
    return nullspace(rows,10)

def slice_basis(bs,rng):
    n=len(bs)
    lin=[rng.randrange(P) for _ in bs]
    while not any(lin):lin=[rng.randrange(P) for _ in bs]
    return [[sum(c*v[j] for c,v in zip(row,bs))%P for j in range(10)] for row in nullspace([lin],n)]

@functools.lru_cache(None)
def mons(n,d):
    return [sum(1<<(4*j) for j in a) for a in it.combinations_with_replacement(range(n),d)]

def polys(A,bs):
    # [u^k] per(J+sA+uB), interpolating s at 5-k distinct values.
    entries=[[(1<<(4*j),row[i]) for j,row in enumerate(bs) if row[i]] for i in range(10)]
    @functools.lru_cache(None)
    def linprod(indices):
        if not indices:return {0:1}
        res=defaultdict(int)
        for mon,c in linprod(indices[:-1]).items():
            for var,d in entries[indices[-1]]:res[mon+var]+=c*d
        return {a:b%P for a,b in res.items() if b%P}
    out=[]
    for k in (2,3,4):
        for s in range(5-k):
            q=[1+s*a for a in A]
            res=defaultdict(int)
            for t,m in terms.items():
                for positions in it.combinations(range(4),k):
                    scalar=m*math.prod(q[t[i]] for i in range(4) if i not in positions)%P
                    if not scalar:continue
                    for mon,c in linprod(tuple(t[i] for i in positions)).items():res[mon]+=scalar*c
            res={a:b%P for a,b in res.items() if b%P}
            if res:out.append((k,res))
    return out

def hilbert(n,eqs,d):
    """Dimension of the homogeneous quotient in degree d, by exact row rank."""
    target=mons(n,d)
    mk={m:k for k,m in enumerate(target)}
    allrows=[(eq,mon) for degree,eq in eqs for mon in (mons(n,d-degree) if degree<=d else [])]
    h=np.zeros((len(allrows),len(target)),dtype=np.int16)
    for i,(eq,off) in enumerate(allrows):
        for m,c in eq.items():h[i,mk[m+off]]=c
    rank=0
    for j in range(len(target)):
        pivots=np.flatnonzero(h[rank:,j])
        if not len(pivots): continue
        row=rank+pivots[0]
        if row!=rank:h[[row,rank]]=h[[rank,row]]
        pivot=h[rank,j:]
        pivot[:]=(pivot*pow(int(pivot[0]),-1,P))%P
        sel=rank+1+np.flatnonzero(h[rank+1:,j])
        if len(sel):h[sel,j:]=(h[sel,j:]-h[sel,j,None]*pivot)%P
        rank+=1
        if rank==len(allrows):break
    return len(target)-rank

def main():
    rng=random.Random(732)
    os=reps()
    print('tangent dims',Counter(len(tangent(a)) for a,n in os),flush=True)
    exceptional=(0,0,0,0,0,0,1,0,4,0)
    assert len(os)==174 and dict(os)[exceptional]==12
    certified=[]
    for i,(a,size) in enumerate(os):
        if a==exceptional:continue
        quotient=tangent(a)
        for attempt in range(60):
            basis=slice_basis(quotient,rng)
            eqs=polys(a,basis)
            for d in (6,7,8):
                h=hilbert(len(basis),eqs,d)
                if h==0:break
            if h==0:break
        assert h==0,(a,d,h)
        certified.append((size,d))
    assert len(certified)==173 and sum(size for size,d in certified)==3906
    print('ordinary orbits',len(certified),'ordinary directions',sum(x[0] for x in certified),
          'certificate degrees', dict(Counter(d for s,d in certified)),flush=True)
if __name__=='__main__':main()
