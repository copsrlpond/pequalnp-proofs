# Run from this directory after chart.py generated ch5-*.in and msolve is available.
# Example: python3.12 chart.py 5 all, then bash reproduce_bound.sh under Ubuntu.
set -eu
for file in ch5-*.in; do
    piv=${file#ch5-};piv=${piv%.in}
    case "$piv" in 0*|123) continue;; esac
    if [ "$(tail -n 1 "$file")" = 1 ]; then continue; fi
    bash solve.sh "$file" 480 1950000 512
    grep -Fxq '[1]:' "$file.out"
done
