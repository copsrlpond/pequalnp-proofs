set -eu
if [ -x root/usr/bin/msolve ]; then
    export LD_LIBRARY_PATH="$PWD/root/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    solver="$PWD/root/usr/bin/msolve"
else
    solver=msolve
fi
export OMP_NUM_THREADS=1
stdbuf -oL -eL "$solver" -l 2 -t 1 -s 14 -m "${4:-0}" -v 2 -g 2 -f "$1" -o "$1.out" > "$1.log" 2>&1 &
job=$!
stop=$((SECONDS + ${2:-10}))
while kill -0 "$job" 2>/dev/null; do
    rss=$(awk '/VmRSS:/ {print $2}' /proc/$job/status 2>/dev/null || true)
    if [ "${rss:-0}" -gt "${3:-450000}" ] || [ "$SECONDS" -ge "$stop" ]; then
        kill -KILL "$job" 2>/dev/null || true
    fi
    sleep 0.03
done
wait "$job"
