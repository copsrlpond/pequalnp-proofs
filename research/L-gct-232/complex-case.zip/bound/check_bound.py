"""Verify all 55 chart input systems by independent direct row-by-row expansion, and read their exact F4 verdicts."""
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FIELD=5
CELLS=[p for p in combinations(range(1,9),3) if p!=(1,2,3)]
assert len(CELLS)==55
ENTRY=[(i,j) for i in range(4) for j in range(i,4)]
PERMS=list(permutations(range(4)))

def normalize(f):
    return tuple(sorted((mon,c%FIELD) for mon,c in f.items() if c%FIELD))

def multiply(f,g):
    prod=defaultdict(int)
    for u,c in f.items():
        for v,d in g.items():prod[tuple(sorted(u+v))]+=c*d
    return prod

def independent(piv):
    # For each point of the flag basis, every matrix entry is an affine form
    # in the free chart variables. Constant monomial is the empty tuple.
    basis=[]
    for row,pos in enumerate(piv):
        m={}; last=defaultdict(int)
        for j,(i,k) in enumerate(ENTRY[:-1]):
            f={}
            if j==pos:f={():1}
            elif j>pos and j not in piv:f={(f'x{row}{j}',):1}
            m[i,k]=m[k,i]=f
            for v,c in f.items():last[v]-=c*(1 if i==k else 2)
        m[3,3]=last;basis.append(m)
    vectors=defaultdict(lambda:defaultdict(int))
    # Assign, separately for each factor in a permutation monomial, the
    # constant term or one of the three basis matrices. Record multiplicity.
    for choices in product(range(-1,3),repeat=4):
        degree=tuple(choices.count(k) for k in range(3))
        if sum(degree)<2:continue
        for sigma in PERMS:
            term={():1}
            for i,b in enumerate(choices):
                if b>=0:term=multiply(term,basis[b][i,sigma[i]])
                if not term:break
            total=vectors[degree]
            for mon,c in term.items():total[mon]+=c
    return [p for f in vectors.values() if (p:=normalize(f))]

def parse(s):
    parts=defaultdict(int)
    for t in s.split('+'):
        c,*factors=t.split('*'); names=[]
        for factor in factors:
            v,sep,e=factor.partition('^');names.extend([v]*(int(e) if sep else 1))
        parts[tuple(sorted(names))]+=int(c)
    return normalize(parts)

result=Counter()
for piv in CELLS:
    name='ch5-'+''.join(map(str,piv))+'.in'; path=ROOT/name
    data=path.read_text().splitlines();assert data[1]=='5',name
    expected=independent(piv)
    direct=any(len(f)==1 and f[0][0]==() for f in expected)
    if direct:
        assert data[2:]==['1'],name
        result['direct nonzero constants']+=1
    else:
        actual=[parse(line.removesuffix(',')) for line in data[2:]]
        assert Counter(expected)==Counter(actual),name
        verdict=(ROOT/(name+'.out')).read_text().splitlines()
        assert '#field characteristic: 5' in verdict and verdict[-1]=='[1]:',name
        assert any('No solution' in line for line in (ROOT/(name+'.log')).read_text().splitlines()),name
        result['unit Groebner bases']+=1
print(len(CELLS),'charts verified;',dict(result))
