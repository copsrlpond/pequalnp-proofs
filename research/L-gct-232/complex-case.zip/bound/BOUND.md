# A dimension bound for the symmetric permanent level at the all-ones matrix

The calculation and row argument give `dim L ≤ 3` over the complex numbers. The project’s conjecture L-gct-232 asks for `dim L ≤ 2`.

Write `J` for the all-ones 4 by 4 matrix. In characteristic 5, consider a three-dimensional space `S` of symmetric matrices with `per(J + T) = 24` identically, `T11 = 0` on `S`, and first-row image of dimension at most two. The computation proves there is no such `S` over an algebraic closure of the field with five elements.

The linear coefficient at `J` is six times the sum of all entries. Eliminate `T44` using the vanishing of that sum. Represent a basis by a row-reduced 3 by 9 matrix in the remaining upper triangular coordinates, in row-major order beginning with `T11`. The first coordinate is zero on `S`, leaving 56 possible pivot triples. With indices starting at zero, exactly `123` gives first-row image of rank three. This leaves 55 cells. For each cell form the permanent of `J + sA + tB + uC` and equate its nonconstant coefficients to zero. On 36 cells a coefficient is a nonzero field constant. On all remaining 19 cells the ideal has reduced Gröbner basis `[1]` in characteristic 5. Exact sparse F4 in msolve 0.9.4 gives these bases.

These rank, vanishing and level conditions define a closed subscheme of a Grassmannian over the integers localized at 5. The Grassmannian is projective. If a complex example existed, the closed image of this subscheme in the base would contain the generic point and thus also the prime 5. The calculation excludes that fiber.

Suppose a complex level space `L` had dimension at least four, and restrict to a four-dimensional subspace. Its first-row image cannot contain `(1,1,1,1)`. If it did, some `T` would have first row `(-1,-1,-1,-1)` and `J + T` would have permanent zero. Thus that image has dimension at most three. If `T11` is nonzero as a functional on `L`, its kernel `S` is three-dimensional and has first-row image of dimension at most two. If `T11` vanishes on all of `L`, choose any three-dimensional subspace of the kernel of `T12` in `L`. Its first-row image again has dimension at most two. Both cases contradict the closed-slice computation.

## Reproduction

Use Python 3.10 or later and the exact msolve 0.9.4 executable. The input files, saved solver outputs and corresponding logs are in this archive. On Linux with Bash and msolve in PATH, run the following from the extracted directory.

```sh
python3 chart.py 5 all
bash reproduce_bound.sh
python3 check_bound.py
```

`check_bound.py` independently reconstructs every coefficient polynomial by assigning a basis vector or the constant 1 to each of the four permutation factors. It compares the entire multiset of polynomials and verifies the recorded solver verdicts. Rerunning the solver independently recomputes the unit ideals. The calculation has no Lean proof in this archive.
