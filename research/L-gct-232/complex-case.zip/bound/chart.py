from collections import defaultdict
from itertools import combinations, permutations
from pathlib import Path
import sys

p=int(sys.argv[1]); target=sys.argv[2] if len(sys.argv)>2 else 'all'
# Order the ten coordinates; choose a final diagonal for tangent elimination.
coords=[(0,0),(0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3)]
field=lambda v:v%p if p else v
def generate(piv):
    variables=[]; vals={}; diag={};
    for j,(r,c) in enumerate(coords):
        vals[r,c] = vals[c,r] = v={0:1}
        for k,pivot in enumerate(piv):
            if j in piv:
                if j!=pivot:continue
                tm=1<<(3*k)
            else:
                if j<pivot:continue
                tm=(1<<(3*k))+(1<<(3*(3+len(variables))))
                variables.append(f'x{k}{j}')
            v[tm]=1;diag[tm]=diag.get(tm,0)-(1 if r==c else 2)
    vals[3,3]={0:1,**diag}
    out=defaultdict(lambda: defaultdict(int))
    for pi in permutations(range(4)):
        acc={0:1}
        for r,c in enumerate(pi):
            nex=defaultdict(int)
            for key,num in acc.items():
                for t,y in vals[r,c].items():nex[key+t]+=num*y
            acc=nex
        for key,num in acc.items():
            if key%512:out[key%512][key//512]+=num
    def term(c,m):
        s=str(c)
        for j,n in enumerate(variables):
            e=m%8;m//=8
            if e:s+='*'+n+(('^'+str(e)) if e>1 else '')
        return s
    eq=[];unit=False
    for pol in out.values():
        pol={m:field(c) for m,c in pol.items() if field(c)}
        if not pol:continue
        if set(pol)=={0}:unit=True;break
        eq.append('+'.join(term(c,m) for m,c in sorted(pol.items())).replace('+-','-'))
    if unit:eq=['1']
    fn='ch'+str(p)+'-'+''.join(map(str,piv))+'.in'
    Path(fn).write_text(','.join(variables or ['dummy'])+'\n'+str(p)+'\n'+',\n'.join(eq)+'\n',encoding='ascii',newline='\n')
    print(fn,len(variables),len(eq),'unit' if unit else '')
for piv in combinations(range(9),3):
    if target=='all' or target==''.join(map(str,piv)):generate(piv)
