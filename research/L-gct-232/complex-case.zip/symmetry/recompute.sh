#!/bin/sh
set -eu
cd "$(dirname "$0")"
node_bin=${NODE:-node}
solver=${MSOLVE:-msolve}
"$node_bin" centered-lines.cjs
"$node_bin" hollow-lines.cjs
for input in center-??.in hollow-?.in; do
    "$solver" -l 2 -t 1 -s 14 -g 2 -f "$input" -o "$input.out"
done
"$node_bin" verify.cjs
