"use strict";
const fs = require("node:fs"), path = require("node:path");
const { addInto, basis4, check, combine, constant, masks, multiply, perms, randomVector, reduce, wedge } = require("./check-involutions.cjs");
const table = [[-1, 0, 1, 2], [0, -1, 3, 4], [1, 3, -1, 5], [2, 4, 5, -1]];
function hollowCoeff(x, d) {
    const q = [...x.slice(0, 5), combine(x, [-1, -1, -1, -1, -1, 0])], o = new Map();
    for (let pi of perms)
        for (let rows of masks)
            if (rows.length === d) {
                let v = constant(1);
                for (let i of rows) {
                    let j = table[i][pi[i]];
                    if (j < 0) {
                        v = constant(0);
                        break;
                    }
                    v = multiply(v, q[j]);
                }
                addInto(o, v);
            }
    return o;
}
const hb = [[10, 7, 10, 14, 4, 6], [7, 11, 6, 5, 16, 7], [14, 14, 0, 8, 1, 14],
    [13, 12, 12, 0, 1, 5], [15, 10, 8, 5, 15, 11], [4, 5, 6, 11, 4, 0]];
const model = { basis: hb };
const q = x => reduce((hollowCoeff(x.map(constant), 2).get(0) || 0) + 3 * x[5] * x[5]);
for (let i = 0; i < 6; i++) {
    check(q(hb[i]) === 0, "Nonisotropic basis vector");
    for (let j = 0; j < i; j++)
        check(q(hb[i].map((a, k) => reduce(a + hb[j][k]))) === Number((i ^ 1) === j), "Incorrect basis pairing");
}
function genPlanes() {
    let tests = [];
    for (let i = 0; i < 40; i++) {
        let a = wedge(model, 0, i < 4 ? basis4[i] : randomVector()), b = wedge(model, 0, randomVector());
        const v = a.map((x, k) => addInto(multiply(a[5], b[k]), multiply(b[5], x), -1));
        tests.push(hollowCoeff(v, 3));
    }
    return tests;
}
const equations = genPlanes();
for (let k = 0; k < 4; k++) {
    const vars = [0, 1, 2, 3].filter(i => i > k).map(i => 'u' + i), es = [];
    for (let f of equations) {
        let g = new Map();
        for (let [key, a] of f) {
            let pow = [];
            for (let i = 0; i < 4; i++)
                pow.push(Math.floor(key / 32 ** i) % 32);
            if (pow.slice(0, k).some(Boolean))
                continue;
            let z = pow.slice(k + 1).join(',');
            g.set(z, reduce((g.get(z) || 0) + a));
        }
        let terms = [];
        for (let [z, c] of g) {
            if (!c)
                continue;
            let pow = z.split(',').map(Number);
            let mon = vars.map((v, j) => pow[j] === 0 ? null : pow[j] === 1 ? v : v + '^' + pow[j]).filter(Boolean);
            terms.push([String(c), ...mon].join('*'));
        }
        if (terms.length)
            es.push(terms.join('+'));
    }
    let out = [vars.join(',') || 'unused', '17', es.join(',\n')].join('\n') + '\n';
    fs.writeFileSync(path.join(__dirname, 'hollow-' + k + '.in'), out);
}
console.log(JSON.stringify(hb));
