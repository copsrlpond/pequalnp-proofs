"use strict";
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
function run(name) {
    execFileSync(process.execPath, [path.join(__dirname, name)], { stdio: "inherit" });
}
run("check-involutions.cjs");
run("centered.cjs");
let empty = 0;
for (let k = 0; k < 4; k++)
    for (let j = 0; j < 4; j++) {
        if (k === j)
            continue;
        const source = fs.readFileSync(path.join(__dirname, `center-${k}${j}.in.out`), "utf8");
        if (!/\[\s*1\s*\]:\s*$/.test(source))
            throw Error("Unexpected centered Gröbner output");
        empty++;
    }
console.log("Centered flag charts with reduced basis [1]:", empty);
run("hollow-extensions.cjs");
