"use strict";
const fs = require("node:fs"), path = require("node:path");
const { addInto, basis4, check, constant, homogeneousRank, masks, multiply, perms, reduce, wedge } = require("./check-involutions.cjs");
const p = 17;
const basis = [[10, 7, 10, 14, 4, 6], [7, 11, 6, 5, 16, 7], [14, 14, 0, 8, 1, 14], [13, 12, 12, 0, 1, 5], [15, 10, 8, 5, 15, 11], [4, 5, 6, 11, 4, 0]];
const table = [[0, 1, 2, 3], [1, 4, 5, 6], [2, 5, 7, 8], [3, 6, 8, 9]];
const plus = (x, y, s = 1) => x.map((a, i) => reduce(a + s * y[i]));
const scale = (x, s) => x.map(a => reduce(a * s));
const zero = n => Array(n).fill(0);
const inv = n => { for (let i = 1; i < p; i++)
    if (reduce(n * i) === 1)
        return i; throw Error("zero pivot"); };
function echelon(V) {
    let rows = [], piv = [];
    for (let v of V) {
        let r = v;
        for (let i = 0; i < piv.length; i++)
            r = plus(r, rows[i], -r[piv[i]]);
        let j = r.findIndex(Boolean);
        if (j < 0)
            continue;
        rows.push(scale(r, inv(r[j])));
        piv.push(j);
    }
    for (let i = rows.length - 1; i >= 0; i--)
        for (let j = 0; j < i; j++)
            rows[j] = plus(rows[j], rows[i], -rows[j][piv[i]]);
    return { rows, piv };
}
function kernel(V) { let { rows, piv } = echelon(V); let free = zero(10).map((_, i) => i).filter(i => !piv.includes(i)); return free.map(i => { let v = zero(10); v[i] = 1; for (let j = 0; j < piv.length; j++)
    v[piv[j]] = reduce(-rows[j][i]); return v; }); }
function evaluate(F, u) { let s = 0; for (let [m, a] of F) {
    let val = a;
    for (let i = 0; i < u.length; i++) {
        let n = Math.floor(m / 32 ** i) % 32;
        for (let j = 0; j < n; j++)
            val = reduce(val * u[i]);
    }
    s += val;
} return reduce(s); }
function perm(z) { let v = 0; for (let pi of perms)
    v += pi.reduce((s, j, i) => s * z[table[i][j]], 1); return reduce(v); }
const O = Array(10).fill(1);
function hollow(x) { return [0, x[0], x[1], x[2], 0, x[3], x[4], 0, reduce(-x.slice(0, 5).reduce((s, t) => s + t, 0)), 0]; }
function candidate(u) {
    const ws = basis4.map(v => wedge({ basis }, 0, v).map(F => evaluate(F, u)));
    let h = ws.find(x => x[5]);
    check(h, "degenerate section");
    let { rows } = echelon(ws.map(w => plus(scale(w, h[5]), h, -w[5])));
    check(rows.length === 2, 'rank of hollow plane');
    let [A, B] = rows.map(hollow);
    for (let i = 0; i <= 4; i++)
        for (let j = 0; j <= 4; j++)
            if (perm(plus(plus(O, A, i), B, j)) !== 24 % 17)
                return null;
    return [A, B];
}
function deriv(z) { let out = zero(10); for (let pi of perms)
    for (let i = 0; i < 4; i++) {
        let v = 1;
        for (let j = 0; j < 4; j++)
            if (i !== j)
                v *= z[table[j][pi[j]]];
        let e = table[i][pi[i]];
        out[e] = reduce(out[e] + v);
    } return out; }
function sections(z, C, d) {
    let out = new Map();
    for (let pi of perms)
        for (let S of masks) {
            if (S.length !== d)
                continue;
            let term = constant(1);
            for (let i = 0; i < 4; i++) {
                let j = table[i][pi[i]];
                term = multiply(term, S.includes(i) ? C[j] : constant(z[j]));
            }
            addInto(out, term);
        }
    return out;
}
function extension(A, B) {
    let zs = [];
    for (let x = 0; x <= 4; x++)
        for (let y = 0; y <= 4; y++)
            zs.push(plus(plus(O, A, x), B, y));
    let K = kernel(zs.map(deriv)), complement = [], span = [A, B];
    for (let w of K) {
        if (echelon([...span, w]).rows.length > span.length) {
            span.push(w);
            complement.push(w);
        }
    }
    check(K.length === span.length, "tangent quotient");
    let n = complement.length;
    if (!n)
        return [n, 0];
    let C = zero(10).map((_, j) => new Map(complement.map((v, i) => [32 ** i, v[j]]).filter(z => z[1])));
    let eq = new Map([2, 3, 4].map(d => [d, zs.map(z => sections(z, C, d)).filter(e => e.size)]));
    for (let d = 2; d <= 8; d++) {
        let [r, s] = homogeneousRank(eq, d, n);
        if (r === s)
            return [n, d];
    }
    throw Error("extension not excluded");
}
function degreeOfChart(k) {
    // The solver uses grevlex and prints the leading term of each basis entry first.
    let out = fs.readFileSync(path.join(__dirname, "hollow-" + k + ".in.out"), "utf8");
    let terms = out.split("[").pop().split("]")[0].trim().split(/,\s*/);
    let vars = [0, 1, 2, 3].filter(i => i > k);
    let leaders = terms.map(t => { let lead = t.split("+")[0], m = new Map([...lead.matchAll(/u(\d+)\^(\d+)/g)].map(z => [+z[1], +z[2]])); return vars.map(i => m.get(i) || 0); });
    if (leaders.some(v => v.every(x => x === 0)))
        return 0;
    let bounds = vars.map((_, i) => Math.min(...leaders.filter(z => z.every((n, j) => j === i || n === 0)).map(z => z[i])));
    check(bounds.every(Number.isFinite), "chart is not zero-dimensional");
    let degree = 0;
    function rec(prefix) {
        if (prefix.length === vars.length) {
            if (leaders.every(L => L.some((v, i) => prefix[i] < v)))
                degree++;
            return;
        }
        for (let i = 0; i < bounds[prefix.length]; i++)
            rec([...prefix, i]);
    }
    rec([]);
    return degree;
}
let total = 0, hist = {};
for (let k = 0; k < 4; k++) {
    let u = zero(4);
    u[k] = 1;
    let count = 0;
    function rec(j) {
        if (j === 4) {
            let G = candidate(u);
            if (G) {
                let key = extension(...G).join(':');
                hist[key] = (hist[key] || 0) + 1;
                count++;
            }
            return;
        }
        for (u[j] = 0; u[j] < p; u[j]++)
            rec(j + 1);
    }
    rec(k + 1);
    let degree = degreeOfChart(k);
    console.log("chart", k, "degree", degree, "rational roots", count);
    check(count === degree, "geometric roots not exhausted");
    total += count;
}
console.log("total checks", total, "by quotient dimension and certificate degree", hist);
