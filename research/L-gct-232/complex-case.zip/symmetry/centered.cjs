// Geometric certificates for centered rows. Coordinate 0..2 is the
// diagonal of a symmetric 3x3 block; coordinates 3..5 are off-diagonals.
"use strict";
const { addInto, basis4, check, combine, constant, homogeneousRank, masks, multiply, perms, randomVector, reduce, wedge } = require("./check-involutions.cjs");
const unit6 = Array.from({ length: 6 }, (_, i) => Array.from({ length: 6 }, (_, j) => Number(i === j)));
const addVector = (a, b, k) => a.map((x, i) => reduce(x + k * b[i]));
const scale = (a, k) => a.map(x => reduce(k * x));
const centered = { basis: [] };
for (let j = 0; j < 6; j += 2) {
    const e = unit6[j], f = unit6[j + 1];
    centered.basis.push(addVector(e, f, 4), scale(addVector(e, f, -4), 13));
}
const walsh = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];
const positions = [[0, 0], [1, 1], [2, 2], [0, 1], [0, 2], [1, 2]];
function centeredEntries(x) {
    return walsh.map(s => walsh.map(t => combine(x, positions.map(([a, b]) => a === b ? s[a] * t[a] : 3 * (s[a] * t[b] + s[b] * t[a])))));
}
function centeredCoeff(x, k) {
    const M = centeredEntries(x), result = new Map();
    for (const pi of perms)
        for (const rows of masks) {
            if (rows.length !== k)
                continue;
            let term = constant(1);
            for (const i of rows)
                term = multiply(term, M[i][pi[i]]);
            addInto(result, term);
        }
    return result;
}
function run() {
    for (const ruling of [0, 1]) {
        const all = new Map([[3, []], [4, []]]);
        for (let k = 0; k < 60; k++) {
            const x = wedge(centered, ruling, k < 4 ? basis4[k] : randomVector());
            for (const degree of [3, 4])
                all.get(degree).push(centeredCoeff(x, degree));
        }
        const degree = ruling === 0 ? 4 : 3;
        const [rank, size] = homogeneousRank(all, degree);
        console.log("Centered ruling", ruling, "degree", degree, "rank", rank + "/" + size);
        check(rank === size, "Incomplete centered certificate");
    }
}
if (require.main === module)
    run();
module.exports = { centered, centeredCoeff };
