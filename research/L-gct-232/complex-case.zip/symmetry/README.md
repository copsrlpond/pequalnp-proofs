# Partial certificates for L-gct-232

Let \(J\) be the all-ones matrix. Suppose \(V\) is a three-dimensional complex linear space of symmetric \(4\times4\) matrices for which \(\operatorname{per}(J+X)=24\) for every \(X\in V\). These computations prove three necessary conditions.

- Only the identity permutation preserves \(V\) under simultaneous permutation of row and column indices.
- The linear map taking \(X\in V\) to its four row sums has rank at least two.
- The linear map taking \(X\in V\) to its diagonal has rank at least two.

Existence of a space satisfying all three conditions remains unresolved. These certificates are independent partial verifications. They are not a Lean proof of the posted statement.

## Running the checks

Node.js 18 or newer is sufficient to run the bundled JavaScript. It has no npm dependencies. The original validation used Node.js 24.14.0. Run the following from the extracted directory.

```sh
node verify.cjs
```

This recomputes all permutation ranks and the hollow-plane extension tests. It reads the sixteen bundled reduced Gröbner bases for the row-sum and diagonal boundary charts. The permutation check, including its exact 3-cycle coefficient expansion, can run by itself in one file with `node check-involutions.cjs`.

To regenerate the Gröbner bases on a machine with POSIX sh, Node.js, and msolve, run the following in a writable extracted directory. The original run used msolve 0.9.4 with one thread. Linux, macOS with a local msolve build, and Windows with WSL can use this workflow. Set `MSOLVE` or `NODE` to select the executable when it is outside the shell's search path.

```sh
sh recompute.sh
```

The script writes the sixteen generated inputs and replaces the reference outputs in that directory. On Windows, the direct Node checks work in PowerShell. Using WSL for all of `recompute.sh` requires Node.js and msolve callable in the WSL shell.

## Why reduction modulo 17 suffices

Let \(f_k(X)=[t^k]\operatorname{per}(J+tX)\). A linear space is a level space precisely when \(f_1,\ldots,f_4\) all vanish identically on it. Vanishing of the coefficients of their restrictions gives closed conditions on a projective Grassmannian over \(\mathbb Z\). The same applies when asking for containment in the centered subspace, or for a pair of nested spaces with the smaller one hollow. Invariance under a fixed permutation is closed as well. Because these parameter spaces are projective, a point in their complex fiber forces a point over the algebraic closure of every residue field. Full-rank homogeneous ideal certificates and unit Gröbner bases test the algebraic closure, including points whose coordinates are outside the prime field.

[PermutationCases.md](PermutationCases.md) gives the details of the permutation argument.

## The row-sum projection

A centered matrix has zero row sums. Write it as \(X=W C W^{\mathsf T}\), where the rows of \(W\) are \((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)\). These columns span the centered three-space over \(\mathbb F_{17}\), so all symmetric centered matrices arise uniquely this way, with \(C\) symmetric. The quadratic condition is \(f_2(X)=16\operatorname{tr}(C^2)\). Parameterize the three diagonal entries of \(C\) by the first three coordinates and its off-diagonal entries by three times the last three coordinates. This makes the quadratic a nonzero scalar multiple of the sum of the six squared coordinates, since \(2\cdot 3^2=1\) modulo 17.

Identify this split six-space with \(\bigwedge^2 k^4\) with its Plücker quadratic, where \(k=\overline{\mathbb F}_{17}\). A totally isotropic two-space is \(u\wedge H\) for a flag consisting of a point \([u]\) in a projective plane \(\mathbf P(H)\). Indeed, a projective line on the Klein quadric is a pencil of projective lines through a point in a plane. If \(\ell\) defines \(H\), choose the first nonzero coordinate \(u_k=1\), then the first nonzero \(\ell_j=1\) among indices other than \(k\). The equation \(\ell(u)=0\) fixes \(\ell_k\). On this chart, two directions spanning \(u\wedge H\) are \(u\wedge(e_r-\ell_r e_j)\) for \(r\notin\{k,j\}\).

The script `centered-lines.cjs` writes \(\left.f_3\right|_{u\wedge H}=\left.f_4\right|_{u\wedge H}=0\) on all twelve ordered-pivot charts. For a homogeneous binary form of degree \(d\), the chosen \(d\) finite evaluations and the evaluation at infinity determine its coefficients in characteristic 17. Each chart's reduced Gröbner basis is \([1]\), so no centered level two-space exists. A three-space with row-sum projection of rank at most one would contain one.

## The diagonal projection

Write a hollow symmetric matrix using its six off-diagonal entries \(x_{ij}\), \(i<j\). Tangency to the level requires their sum to vanish. If \(M=x_{12}x_{34}+x_{13}x_{24}+x_{14}x_{23}\), direct expansion gives \(f_2=4M\) on that tangent space, and \(f_4=M^2\). The remaining equation is the cubic.

The five-dimensional tangent quadratic becomes a split six-dimensional form by adjoining \(3z^2\) over \(\mathbb F_{17}\), as the verifier checks directly. An isotropic two-space in the five-space is the intersection \(W_u\cap\{z=0\}\) for the unique maximal isotropic \(W_u\) of one chosen ruling that contains it. The quadratic on the five-space is nondegenerate, so \(W_u\) cannot lie in \(z=0\). Let \(X=u\wedge v\) and \(Y=u\wedge w\). Then \(Z=z(X)Y-z(Y)X\) is in this two-space. The program `hollow-lines.cjs` computes necessary cubic equations \(f_3(Z)=0\) by sampling \(v,w\). Every genuine hollow level two-space satisfies these equations.

The four affine projective charts have Gröbner quotient lengths \(21,3,0,0\). Independently, `hollow-extensions.cjs` enumerates the normalized \(\mathbb F_{17}\) points, constructs each actual two-space, and directly checks the full permanent. It finds exactly \(21,3,0,0\) distinct rational points. Since these counts attain the chart lengths, there are no uncounted geometric points or multiplicities.

For each of the 24 planes with basis \(A,B\), the same verifier computes all symmetric directions \(C\) satisfying the linear coefficient of \(t\) in \(\operatorname{per}(J+xA+yB+tC)\) for every \(x,y\). It quotients this kernel by \(A,B\). In the remaining homogeneous coordinates it imposes the degree-two through degree-four coefficients in \(t\), using \(x,y\in\{0,1,2,3,4\}\). Sixteen quotients have dimension two and full ideal rank in degree four. Eight have dimension one and full rank in degree two. No geometric extension to a three-space exists. Consequently the diagonal projection of any complex candidate has rank at least two.

