// Exact certificates for involution-invariant symmetric level spaces in size four.
// Run with Node.js. All polynomial calculations use F_17 and integer arithmetic.
// A full degree-d row span rules out solutions over its algebraic closure.
// The Grassmannian locus is projective over Z, so an empty fiber rules out complex points.
"use strict";
const p = 17;
const reduce = value => ((value % p) + p) % p;
function inverse(value) {
    for (let i = 1; i < p; i++)
        if (reduce(i * value) === 1)
            return i;
    throw new Error("Zero pivot");
}
function check(condition, message) {
    if (!condition)
        throw new Error(message);
}
const transposition = {
    name: "(12)",
    // The six tangent coordinates are a,b,c,d,e,f. The entry numbered 6 is
    // g = -2a-2b-4c-4d-e-2f, because the sum of all entries vanishes.
    table: [[0, 1, 2, 3], [1, 0, 2, 3], [2, 2, 4, 5], [3, 3, 5, 6]],
    tail: [-2, -2, -4, -4, -1, -2],
    auxiliary: 0,
    basis: [[5, 12, 12, 15, 6, 11], [8, 13, 13, 12, 15, 2], [13, 13, 11, 12, 6, 7],
        [7, 12, 6, 15, 1, 10], [1, 3, 0, 1, 0, 4], [11, 0, 16, 15, 11, 4]]
};
const doubleTransposition = {
    name: "(12)(34)",
    // Original coordinates a,b,c,d,e; coordinate 5 is auxiliary z.
    // Entry 6 is f=-a-b-2c-2d-e; the auxiliary term 3z^2 splits the form.
    table: [[0, 1, 2, 3], [1, 0, 3, 2], [2, 3, 4, 6], [3, 2, 6, 4]],
    tail: [-1, -1, -2, -2, -1, 0],
    auxiliary: 3,
    basis: [[7, 9, 1, 6, 2, 0], [12, 8, 16, 11, 15, 0], [7, 13, 5, 8, 11, 5],
        [10, 5, 8, 7, 14, 7], [15, 15, 5, 7, 14, 2], [6, 6, 15, 11, 14, 13]]
};
function* tuples(n, degree, prefix = []) {
    if (n === 1) {
        yield [...prefix, degree];
        return;
    }
    for (let j = 0; j <= degree; j++)
        yield* tuples(n - 1, degree - j, [...prefix, j]);
}
function* permutations(available, prefix = []) {
    if (!available.length)
        yield prefix;
    for (const i of available)
        yield* permutations(available.filter(j => j !== i), [...prefix, i]);
}
const perms = [...permutations([0, 1, 2, 3])];
const masks = Array.from({ length: 16 }, (_, mask) => [0, 1, 2, 3].filter(i => (mask & (1 << i)) !== 0));
const basis4 = [0, 1, 2, 3].map(i => [0, 1, 2, 3].map(j => Number(i === j)));
// A sparse polynomial maps a monomial to its coefficient. Pack four exponents
// in base 32. The degrees in this calculation are at most nine.
const pack = powers => powers.reduceRight((key, exponent) => key * 32 + exponent, 0);
const variables = [1, 32, 1024, 32768];
const constant = n => n ? new Map([[0, reduce(n)]]) : new Map();
function addInto(sum, other, scale = 1) {
    for (const [monomial, coefficient] of other) {
        const updated = reduce((sum.get(monomial) || 0) + scale * coefficient);
        if (updated)
            sum.set(monomial, updated);
        else
            sum.delete(monomial);
    }
    return sum;
}
function multiply(left, right) {
    const product = new Map();
    for (const [x, a] of left) {
        for (const [y, b] of right) {
            const key = x + y;
            const sum = reduce((product.get(key) || 0) + a * b);
            if (sum)
                product.set(key, sum);
            else
                product.delete(key);
        }
    }
    return product;
}
const combine = (entries, coefficients) => entries.reduce((sum, entry, i) => addInto(sum, entry, coefficients[i]), new Map());
const zeroMatrix = Array.from({ length: 4 }, () => Array(4).fill(0));
function oddMatrix(diagonal) {
    // Two representatives of all admissible odd lines for (12), up to (34).
    return [[diagonal, 0, 1, 0], [0, -diagonal, -1, 0], [1, -1, 0, 0], [0, 0, 0, 0]];
}
// Coefficient of s^a t^b in per(J+sA+tX). X lies in the chosen even space.
function coefficient(model, coords, b, odd = zeroMatrix, a = 0) {
    const entries = [...coords, combine(coords, model.tail)];
    const result = new Map();
    for (const pi of perms) {
        for (const oddRows of masks) {
            if (oddRows.length !== a)
                continue;
            const factor = oddRows.reduce((v, i) => v * odd[i][pi[i]], 1);
            if (!factor)
                continue;
            for (const evenRows of masks) {
                if (evenRows.length !== b || evenRows.some(i => oddRows.includes(i)))
                    continue;
                let term = constant(factor);
                for (const i of evenRows)
                    term = multiply(term, entries[model.table[i][pi[i]]]);
                addInto(result, term);
            }
        }
    }
    return result;
}
function verifyBasis(model) {
    const q = v => reduce((coefficient(model, v.map(constant), 2).get(0) || 0)
        + model.auxiliary * v[5] ** 2);
    for (let i = 0; i < 6; i++) {
        const x = model.basis[i];
        check(q(x) === 0, "Basis vector is not isotropic");
        for (let j = 0; j < i; j++) {
            const y = model.basis[j];
            const paired = q(x.map((v, k) => reduce(v + y[k])));
            check(paired === Number((i ^ 1) === j), "Incorrect hyperbolic pairing");
        }
    }
}
// Identify the split quadratic form with the Plücker form on ∧²F^4.
// One ruling is formed by all W_u = u∧F^4. Swapping a hyperbolic pair gives
// the second ruling. For fixed v this returns the six coordinates of u∧v.
function wedge(model, ruling, v) {
    const [e0, f0, e1, f1, e2, f2] = model.basis;
    const basis = [e0, e1, e2, f2, f1.map(x => -x), f0];
    if (ruling)
        [basis[0], basis[5]] = [basis[5], basis[0]];
    const pairs = [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]];
    const entries = Array.from({ length: 6 }, () => new Map());
    pairs.forEach(([i, j], k) => {
        const term = new Map([[variables[i], v[j]], [variables[j], -v[i]]]);
        entries.forEach((entry, n) => addInto(entry, term, basis[k][n]));
    });
    return entries;
}
let randomState = 1253210;
function randomVector() {
    return basis4.map(() => {
        randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0;
        return randomState % p;
    });
}
// The deterministic samples supply necessary equations. Full row span below
// verifies that they suffice, independently of how the samples were selected.
function equations(model, ruling, kind) {
    const all = new Map();
    function record(degree, equation) {
        if (!equation.size)
            return;
        if (!all.has(degree))
            all.set(degree, []);
        all.get(degree).push(equation);
    }
    const odd = oddMatrix(kind === "mixed" ? -4 : 0);
    const hyperplane = coords => kind === "auxiliary" ? coords[5] : coefficient(model, coords, 1, odd, 2);
    const generatorDegree = kind === "fixed" ? 1 : 2;
    for (let k = 0; k < 70; k++) {
        const v = k < 4 ? basis4[k] : randomVector();
        let X = wedge(model, ruling, v);
        if (kind !== "fixed") {
            const Y = wedge(model, ruling, randomVector());
            const lx = hyperplane(X);
            const ly = hyperplane(Y);
            // These are vectors of W_u in the required hyperplane.
            X = X.map((x, j) => addInto(multiply(lx, Y[j]), multiply(ly, x), -1));
            if (kind !== "auxiliary")
                record(4, coefficient(model, X, 2, odd, 2));
        }
        for (const k of [3, 4])
            record(k * generatorDegree, coefficient(model, X, k));
    }
    return all;
}
function homogeneousRank(equations, degree, variableCount = 4) {
    const keys = [...tuples(variableCount, degree)].map(pack);
    const places = new Map(keys.map((key, i) => [key, i]));
    const pivots = Array(keys.length);
    let rank = 0;
    for (const [degreeOfEquation, polynomials] of [...equations].sort((a, b) => a[0] - b[0])) {
        if (degreeOfEquation > degree)
            continue;
        for (const exponents of tuples(variableCount, degree - degreeOfEquation)) {
            const multiplier = pack(exponents);
            for (const equation of polynomials) {
                const row = new Uint8Array(keys.length);
                for (const [monomial, value] of equation) {
                    const index = places.get(monomial + multiplier);
                    check(index !== undefined, "Nonhomogeneous row");
                    row[index] = value;
                }
                for (let k = 0; k < keys.length; k++) {
                    const lead = row[k];
                    if (!lead)
                        continue;
                    const pivot = pivots[k];
                    if (!pivot) {
                        const scale = inverse(lead);
                        for (let j = k; j < keys.length; j++)
                            row[j] = (row[j] * scale) % p;
                        pivots[k] = row;
                        rank++;
                        break;
                    }
                    for (let j = k; j < keys.length; j++)
                        row[j] = (row[j] + p * p - lead * pivot[j]) % p;
                }
                if (rank === keys.length)
                    return [rank, keys.length];
            }
        }
    }
    return [rank, keys.length];
}
function runPermutationChecks() {
    for (const model of [transposition, doubleTransposition])
        verifyBasis(model);
    for (const [model, ruling, kind, degree] of [
        [transposition, 0, "fixed", 3], [transposition, 1, "fixed", 3],
        [transposition, 0, "pure", 8], [transposition, 0, "mixed", 7],
        [doubleTransposition, 0, "auxiliary", 9]
    ]) {
        const [rank, size] = homogeneousRank(equations(model, ruling, kind), degree);
        console.log(model.name, kind, "ruling", ruling, "degree", degree, "rank", rank + "/" + size);
        check(rank === size, "Certificate incomplete");
    }
    // The 3-cycle fixes tail diagonal g, tail off-diagonal h, cross i, and
    // first diagonal -3g-6h-6i. The first-order coefficient has already vanished.
    const threeCycle = {
        table: [[3, 2, 2, 2], [2, 0, 1, 1], [2, 1, 0, 1], [2, 1, 1, 0]],
        tail: [-3, -6, -6]
    };
    const ghis = variables.slice(0, 3).map(key => new Map([[key, 1]]));
    const threeCycleEquations = new Map([2, 3, 4].map(k => [k, [coefficient(threeCycle, ghis, k)]]));
    const [rank3, size3] = homogeneousRank(threeCycleEquations, 7, 3);
    console.log("(123) fixed directions, degree 7 rank", rank3 + "/" + size3);
    check(rank3 === size3, "3-cycle certificate incomplete");
    // Verify the 3-cycle eigen-cubic exactly in Z[omega]/(1+omega+omega^2).
    // For a term of degree k, count its coefficient at 1, omega, and omega^2,
    // then subtract the last count from each of the first two.
    function tailCharacterEntry(i, j) {
        if (i === 0 && j === 0)
            return null;
        if (i === 0 || j === 0)
            return ["c", Math.max(i, j) - 1];
        if (i === j)
            return ["a", i - 1];
        return ["b", 5 - i - j];
    }
    const counts = new Map();
    for (const pi of perms) {
        for (const rows of masks) {
            const terms = rows.map(i => tailCharacterEntry(i, pi[i]));
            if (terms.includes(null))
                continue;
            const monomial = terms.map(term => term[0]).sort().join("");
            const exponent = terms.reduce((sum, term) => sum + term[1], 0) % 3;
            if (!counts.has(monomial))
                counts.set(monomial, [0, 0, 0]);
            counts.get(monomial)[exponent]++;
        }
    }
    const exactCubic = new Map(Object.entries({
        "": 24, aaa: 1, abb: 3, bbb: 2, aac: 6, abc: -6, acc: 3, bcc: 6
    }));
    for (const [monomial, [one, omega, omega2]] of counts) {
        check(omega === omega2 && one - omega2 === (exactCubic.get(monomial) || 0), "3-cycle eigen-cubic coefficient mismatch");
        exactCubic.delete(monomial);
    }
    check(exactCubic.size === 0, "Missing eigen-cubic term");
    console.log("(123) eigen-cubic coefficients verified over the Eisenstein integers");
    // Independently expand the odd eigenspace formulas used in the cone argument.
    function checkOddPolynomial(names, signs, degree, expected) {
        const actual = new Map();
        for (const pi of perms)
            for (const rows of masks) {
                if (rows.length !== degree)
                    continue;
                const key = rows.map(i => names[i][pi[i]]).sort().join("");
                const value = rows.reduce((n, i) => n * signs[i][pi[i]], 1);
                if (value)
                    actual.set(key, (actual.get(key) || 0) + value);
            }
        for (const [key, value] of actual) {
            check(value === (expected[key] || 0), "Odd polynomial coefficient mismatch");
            delete expected[key];
        }
        check(!Object.keys(expected).length, "Missing odd coefficient");
    }
    const singleNames = [["a", "", "b", "c"], ["", "a", "b", "c"],
        ["b", "b", "", ""], ["c", "c", "", ""]];
    const singleSigns = [[1, 0, 1, 1], [0, -1, -1, -1], [1, -1, 0, 0], [1, -1, 0, 0]];
    checkOddPolynomial(singleNames, singleSigns, 2, { aa: -2, ab: -8, ac: -8, bc: -8 });
    checkOddPolynomial(singleNames, singleSigns, 4, { bbcc: 4 });
    const doubleNames = [["a", "", "c", "d"], ["", "a", "d", "c"],
        ["c", "d", "b", ""], ["d", "c", "", "b"]];
    const doubleSigns = [[1, 0, 1, 1], [0, -1, -1, -1], [1, -1, 1, 0], [1, -1, 0, -1]];
    checkOddPolynomial(doubleNames, doubleSigns, 2, { aa: -2, bb: -2, cc: -4, dd: -4, ac: -8, ad: -8, bc: -8, bd: 8 });
    checkOddPolynomial(doubleNames, doubleSigns, 4, { aabb: 1, abcc: 2, abdd: -2, cccc: 1, ccdd: 2, dddd: 1 });
    console.log("Odd eigenspace polynomials verified over the integers");
}
if (require.main === module)
    runPermutationChecks();
module.exports = {
    addInto, basis4, check, combine, constant, homogeneousRank, masks, multiply,
    perms, randomVector, reduce, wedge
};
