"use strict";
const fs = require("node:fs"), path = require("node:path");
const { addInto, combine, constant, multiply, reduce } = require("./check-involutions.cjs");
const { centered, centeredCoeff } = require("./centered.cjs");
const coords = [0, 1, 2, 3], pairs = [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]];
const [e0, f0, e1, f1, e2, f2] = centered.basis;
const b = [e0, e1, e2, f2, f1.map(x => -x), f0];
function wedge(u, v) {
    const minor = pairs.map(([i, j]) => addInto(multiply(u[i], v[j]), multiply(u[j], v[i]), -1));
    return Array.from({ length: 6 }, (_, k) => combine(minor, b.map(row => row[k])));
}
function encoded(F, vars) {
    let terms = [];
    for (let [m, c] of F) {
        let factors = [String(c)];
        for (let i = 0; i < vars.length; i++) {
            let a = Math.floor(m / 32 ** i) % 32;
            if (a)
                factors.push(a === 1 ? vars[i] : vars[i] + "^" + a);
        }
        terms.push(factors.join("*"));
    }
    return terms.join("+") || "0";
}
for (let k of coords)
    for (let j of coords) {
        if (k === j)
            continue;
        const vars = [];
        const variable = () => { let t = vars.length; vars.push("x" + t); return new Map([[32 ** t, 1]]); };
        const u = coords.map(i => i < k ? constant(0) : i === k ? constant(1) : variable());
        const l = coords.map(i => i === k ? constant(0) : i < j ? constant(0) : i === j ? constant(1) : variable());
        // The covector's kth entry is fixed by l(u)=0, but is never needed:
        // use representatives v with v[k]=0 for v modulo the span of u.
        const generators = coords.filter(i => i !== k && i !== j).map(r => {
            let v = coords.map(i => constant(Number(i === r)));
            addInto(v[j], l[r], -1);
            return wedge(u, v);
        });
        const [A, B] = generators;
        let equations = [];
        for (let d of [3, 4]) {
            // d evaluations at finite t and one at infinity determine a binary form.
            for (let t = 0; t < d; t++)
                equations.push(centeredCoeff(A.map((x, i) => addInto(new Map(x), B[i], t)), d));
            equations.push(centeredCoeff(B, d));
        }
        const nonzero = equations.filter(x => x.size);
        if (!vars.length)
            vars.push("unused");
        let out = [vars.join(","), "17", nonzero.map(x => encoded(x, vars)).join(",\n")].join("\n") + "\n";
        fs.writeFileSync(path.join(__dirname, "center-" + k + j + ".in"), out);
    }
