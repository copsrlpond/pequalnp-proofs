# Permutation-invariant three-dimensional candidates for L-gct-232

Let \(J\) denote the all-ones matrix. A level space is a linear space \(V\) of symmetric \(4\times4\) complex matrices such that \(\operatorname{per}(J+X)=24\) for every \(X\in V\). If \(\dim V=3\), its stabilizer under simultaneous permutations of the rows and columns is trivial.

This is a partial result about L-gct-232. Asymmetric candidates remain possible.

## Verification

Run `node check-involutions.cjs` in this directory. No packages are needed. The script expands the permanent over its 24 permutations. Its modular certificates use the prime 17.

A homogeneous degree-\(d\) certificate consists of rows for monomial multiples of necessary equations, expanded in the basis of all degree-\(d\) monomials. Full row span puts every such monomial in the ideal. Thus no nonzero solution exists even over the algebraic closure of the finite field. To transfer emptiness to characteristic zero, take the locus in the appropriate projective Grassmannian cut out by constancy of the restricted permanent and permutation invariance. Those conditions are closed and defined over the integers. A nonempty generic fiber has nonempty special fiber at every prime by properness. The same argument applies to the fixed-direction locus in projective space.

Write \(f_k(X)=[t^k]\operatorname{per}(J+tX)\). The first coefficient gives \(\sum X_{ij}=0\). On this tangent hyperplane \(f_2=\sum_{ij}X_{ij}^2-2\sum_i(\sum_j X_{ij})^2\).

## A transposition

For the swap \((12)\), decompose \(V\) into even and odd eigenspaces. The odd direction has diagonal \((a,-a,0,0)\) and cross entries \(X_{13}=b,\ X_{23}=-b,\ X_{14}=c,\ X_{24}=-c\), with the other entries zero. Here \(f_4=4b^2c^2\) and \(f_2=-2a^2-8a(b+c)-8bc\). Consequently only four projective odd directions can occur. Up to the swap \((34)\), the two representatives have \((a,b,c)=(0,1,0)\) or \((-4,1,0)\). Thus either all three dimensions are even, or exactly two are even.

The six-dimensional even tangent space is a split quadratic space over \(\mathbb F_{17}\). The verifier checks a hyperbolic basis and identifies its form with the Plücker quadratic on \(\bigwedge^2 k^4\). Over an algebraically closed field the maximal isotropic three-planes have two rulings. The first consists of \(W_u=u\wedge k^4\), indexed by \([u]\in\mathbf P^3\). Swapping one hyperbolic pair gives the other ruling. These descriptions follow from the two families of planes on the Klein quadric. Every isotropic two-space lies in one maximal three-space of each ruling.

For an all-even three-space, \(f_3,f_4\) must vanish on each \(u\wedge v\). Sampling finitely many vectors \(v\) gives rank 20 out of 20 in homogeneous degree 3 for each ruling. For an odd representative \(A\), let \(\ell(X)=[s^2t]\operatorname{per}(J+sA+tX)\). The even two-space \(U\) is contained in its kernel. Choose \(W_u\) of the first ruling containing \(U\). If \(\ell\) is nonzero on \(W_u\), then \(U=W_u\cap\ker\ell\). For \(X=u\wedge v,\ Y=u\wedge w\), the vector \(Z=\ell(X)Y-\ell(Y)X\) is in \(U\). If \(\ell\) vanishes on the whole \(W_u\), these vectors are zero and still satisfy the necessary equations. Therefore \(f_3(Z),f_4(Z)\) and \([s^2t^2]\operatorname{per}(J+sA+tZ)\) must vanish. The two odd representatives give full ranks 165/165 in degree 8 and 120/120 in degree 7. These deterministic samples are sufficient because their coefficient rank is verified directly.

## Two disjoint transpositions

For \((12)(34)\), an even direction has rows \((a,b,c,d),(b,a,d,c),(c,d,e,f),(d,c,f,e)\), with \(f=-a-b-2c-2d-e\). Adjoin an auxiliary coordinate \(z\) and add \(3z^2\) to the five-dimensional tangent quadratic over \(\mathbb F_{17}\). The verifier checks that the six-dimensional form is split. An even isotropic two-space lies in a \(W_u\) of the first ruling and in \(z=0\). Taking \(\ell=z\) in the same construction, the necessary conditions \(f_3(Z)=f_4(Z)=0\) give full rank 220/220 in degree 9. There is no even level two-space.

An odd matrix has rows \((a,0,c,d),(0,-a,-d,-c),(c,-d,b,0),(d,-c,0,-b)\). Its quartic is
\[
 [ab+(c+i d)^2][ab+(c-i d)^2].
\]
A projective line on either rank-three quadric cone contains its vertex. Take the first factor and write \(w=c+i d\). The vertex has \((a,b,c,d)=(0,0,-i,1)\). Polarizing \(f_2\) against it gives \(w=-(a+b)-i(a-b)\) on a putative line. Set \(s=a+b,\ t=a-b\). With \(ab+w^2=0\), the condition \(f_2=0\) reads \((t-2is)^2=0\). But \(4(ab+w^2)=5(s^2-t^2)+8ist\), which at \(t=2is\) forces \(9s^2=0\). Only the vertex remains. Complex conjugation handles the second factor. Neither eigenspace contains two dimensions, so their sum cannot supply three.

## A 3-cycle

Write a fixed direction for a cycle permuting the last three indices using tail diagonal \(g\), tail off-diagonal \(h\), first row/column cross \(i\), and first diagonal \(-3g-6h-6i\). The equations \(f_2=f_3=f_4=0\) have rank 36/36 in degree 7. The fixed eigenspace supplies no nonzero level direction.

For a nontrivial cube root \(\omega\), write tail diagonal \(a(1,\omega,\omega^2)\), tail off-diagonal \(b(1,\omega,\omega^2)\) indexed by missing vertex, and cross \(c(1,\omega,\omega^2)\). The verifier expands the permanent exactly over the Eisenstein integers. The only nonconstant coefficient is
\[
  a^3+3ab^2+2b^3+6a(a-b)c+3(a+2b)c^2.
\]
It has no linear factor over \(\mathbb C\). Its three coefficients as a polynomial in \(c\) have no common divisor. Its discriminant is \(24(a^4-4a^3b-4ab^3-2b^4)\). After normalizing, a square would have to be \((a^2-2ab-2b^2)^2\) by its first three coefficients, whereas its \(ab^3\) coefficient would then be \(8\). This proves irreducibility by the quadratic criterion. An eigenspace level two-plane would give a line on that plane cubic, hence a linear factor. The conjugate eigenspace satisfies the same restriction. Neither can supply two dimensions.

Every nontrivial subgroup of \(S_4\) contains a transposition, a product of two disjoint transpositions, or a 3-cycle. In particular the square of any 4-cycle is a double transposition. This exhausts the nontrivial stabilizers.

